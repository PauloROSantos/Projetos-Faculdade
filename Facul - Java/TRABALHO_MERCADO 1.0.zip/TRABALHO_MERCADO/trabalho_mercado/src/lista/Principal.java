package lista;

import trabalho_mercado.Caixa;

public class Principal {
	public static void main(String args[]){
		ListaLigada lista = new ListaLigada();
		
		lista.adicionar(new Caixa());
	}
}
